﻿#include <stdio.h>
#define _CRT_SECURE_NO_WARNINGS
#define MAX 19

/*
Napisati funkciju void izbaci(int a[], int *pn, int x)
koja iz niza a izbacuje sva pojavljivanja elementa x.
Funkcija ažurira dimenziju niza preko pokazivača pn.
Na primer: za niz 8 4 2 8 0 -3 dužine 6 i element 8 novi niz je 4 2 0 -3 i nova dužina je 4.
U glavnom programu učitati dimenziju niza (n < 20) i elemente niza i testirati rad funkcije.
*/

void izbaci(int a[], int* pn, int x) {

	int i, j;
	pn = a;

	for (i = 0, j = 0; i < MAX && j < MAX; ) {
		if (*(pn + i) == x) {

			i++;
		}
		else
		{
			a[j] = *(pn + i);
			i++;
			j++;
		}
	}
}

int main() {
	int a[MAX] = { 1, 2, 3, 3, 3, 3, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18 };
	int* pn = a;
	int x = 16, countX = 0;

	for (int i = 0; i < MAX; i++) {
		if (a[i] == x) {
			countX++;
		}
	}

	izbaci(a, *pn, x);

	printf("Niz je promenjen i uklonjeno je svako ponavljanje elementa : %d\n", x);

	for (int i = 0; i < MAX - countX; i++)
	{
		printf("%d\n", a[i]);
	}

	return 0;
}