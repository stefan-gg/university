﻿#include <stdio.h>
#define _CRT_SECURE_NO_WARNINGS
#define MAX 20

//Napisati funkciju kojom se elementi niza 
//pomeraju za jednu poziciju ulevo.
//Na primer : ako je dat niz 1 2 3 4 5, posle pomeranja za poziciju ulevo niz je 2 3 4 5 1.
//Implementirati funkciju isključivo korišćenjem pokazivača, a prototip funkcije je : void izmeni(int* Niz, int n)
// b) void izmeni (int *Niz, int n, int m) za proizvoljan broj elemenata se pomeri


//nisam znao koja je uloga parametra int n tako da sam uradio oba zadatka bez njega
void izmeni(int* niz) {
	int n = 0, nPrvo = niz[0], i;
	for (i = 0; i < MAX - 1; i++) {
		*(niz + i) = *(niz + i + 1);
	}
	*(niz + MAX - 1) = nPrvo;
}

void izmeniProizvoljno(int* niz, int m) {
	int tempNiz[MAX];
	int i, j;

	if (m > MAX) {
		m = 0;
	}

	for (j = 0; j < m; j++) {
		tempNiz[j] = niz[j];
	}

	for (i = 0; i < MAX - m; i++)
	{
		*(niz + i) = *(niz + i + m);
	}
	
	for (i = m, j = 0; i >= 0 && j < m; i--, j++) {
		niz[MAX - i] = tempNiz[j];
	}
}

int main() {
	int n = 20;
	int* niz[MAX] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20};
	
	izmeni(niz);
	printf("Niz pomeren ulevo za 1 :\n");
	for (int i = 0; i < MAX; i++)
	{
		printf("%d \n", niz[i]);
	}

	izmeniProizvoljno(niz,n);
	printf("Niz pomeren ulevo za %d :\n", n);
	for (int i = 0; i < MAX; i++)
	{
		printf("%d \n", niz[i]);
	}
	
	return 0;
}