#pragma once
#include "ImeNijeValidnoException.h"

class Sat {
private:
	string ime;
	string model;
	int godinaProizvodnje;
	int trajanjeBaterije;

public:

	Sat() {}
	Sat(string ime, string model, int godinaProizvodnje, int trajanjeBaterije) : ime(ime), model(model), godinaProizvodnje(godinaProizvodnje),
		trajanjeBaterije(trajanjeBaterije){ setIme(ime); }
	~Sat() {}

	void setIme(string ime) {
		try {
			if (ime.length() > 3) {
				this->ime = ime;
				cout << "a" << endl;
			}
			else {
				cout << "aaa" << endl;
				throw ImeNijeValidnoException();
			}
		}
		catch (ImeNijeValidnoException& e) {
			cerr << e.what() << endl;
		}
	}
};