#include "Student.h"
#include "Sat.h"
/*7. Kreirati osnovnu klasu za studente. 
Svaki student ima: ime, prezime, adresu, grad, indeks.
Ukoliko prezime studenta nema makar 3 karaktera treba 
da se desi PrezimeNijeValidnoException.*/

/*22. Na�a firma se bavi proizvodnjom satova. 
Svaki sat ima svoje ime, model, godinu proizvodnje kao i trajanje baterije.
Ukoliko se desi da ime ima manje od 2 
karaktera treba da se desi ImeNijeValidnoException.*/

int main() {

	Student("a", "a", "a", "a", 1);
	Sat("a", "a", 2, 2);

	return 0;
}