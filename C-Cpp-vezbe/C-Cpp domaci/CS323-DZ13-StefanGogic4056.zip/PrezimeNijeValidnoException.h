#pragma once
#include <iostream>
using namespace std;
#include <exception>

class PrezimeNijeValidnoException : public exception {
public:
	virtual const char* what() const noexcept {
		return "Prezime ima manje od 3 karaktera.";
	}
};