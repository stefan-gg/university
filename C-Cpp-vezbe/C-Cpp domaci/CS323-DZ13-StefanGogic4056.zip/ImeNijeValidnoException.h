#pragma once
#include <iostream>
using namespace std;
#include <exception>

class ImeNijeValidnoException : public exception {
public:
	virtual const char* what() const noexcept {
		return "Ime ima manje od 2 karaktera.";
	}
};