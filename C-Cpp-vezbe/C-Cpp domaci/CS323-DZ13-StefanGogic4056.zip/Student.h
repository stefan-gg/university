#pragma once
#include "PrezimeNijeValidnoException.h"

class Student {
private:
	string ime;
	string prezime;
	string adresa;
	string grad;
	int indeks;

public:

	Student() {}
	Student(string ime, string prezime, string adresa, string grad, int indeks) : ime(ime), adresa(adresa), grad(grad), indeks(indeks) { setPrezime(prezime); }
	~Student(){}

	void setPrezime(string prezime) {
		try {
			if (prezime.length() > 3) {
				this->prezime = prezime;
				cout << "a" << endl;
			}
			else {
				cout << "aaa" << endl;
				throw PrezimeNijeValidnoException();
			}
		}
		catch (PrezimeNijeValidnoException& e) {
			cerr << e.what() << endl;
		}
	}
};