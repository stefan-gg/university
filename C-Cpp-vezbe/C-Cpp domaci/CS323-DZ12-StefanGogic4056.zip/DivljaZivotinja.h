#pragma once
#include "Zivotinja.h"
class DivljaZivotinja : protected Zivotinja
{
private:
	string loviste;
public:
	DivljaZivotinja() {}
	virtual ~DivljaZivotinja() {}
	DivljaZivotinja(string ime, string zvuk, string pol, int starost, int brojNogu, string loviste) : 
		Zivotinja(ime, zvuk, pol, starost, brojNogu), loviste(loviste) {};

	string info();

	string getIme() {
		return this->ime;
	}

	string getZvuk() {
		return this->zvuk;
	}

	string getPol() {
		return this->pol;
	}

	string getLoviste() {
		return this->loviste;
	}

	int getStarost() {
		return this->starost;
	}

	int getBrojNogu() {
		return this->brojNogu;
	}
	
	ostream& operator<<(ostream& out);

	bool operator==(const DivljaZivotinja& dz);

	
};

