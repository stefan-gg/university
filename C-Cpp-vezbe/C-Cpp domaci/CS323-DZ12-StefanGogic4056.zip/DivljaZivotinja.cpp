#include "DivljaZivotinja.h"

string DivljaZivotinja::info()
{
	string str = this->ime;
	str += " " + this->loviste;
	str += " " + this->pol;
	str += " " + this->zvuk;
	str += " " + to_string(this->starost);
	str += " " + to_string(this->brojNogu);
	return str;
}

ostream& DivljaZivotinja::operator<<(ostream& out)
{
	out << this->ime << " " << this->pol << " " << this->starost << " " << this->brojNogu << " " << this->zvuk << " "
		<< this->loviste << " " << endl;
	return out;
}

bool DivljaZivotinja::operator==(const DivljaZivotinja& dz) {
	bool bol = false;
	if (this->ime == dz.ime && this->loviste == dz.loviste && this->zvuk == dz.zvuk) {
		bol = true;
	}
	return bol;
}

