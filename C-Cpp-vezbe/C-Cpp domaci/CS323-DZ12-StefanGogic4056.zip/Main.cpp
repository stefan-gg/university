﻿#include "DivljaZivotinja.h"
#include <vector>
#include <iterator>
#include<cstdlib>
#include <fstream>
#include <stack>


/*Napraviti klasu Životinja.
Klasa Životinja mora imati makar 5 atributa po slobodnom izboru.
Klasa Životinja treba biti kreirana kao apsrtaktna i da 
sadrži čisto virtuelnu funkciju Info().
Potom kreirati izvedenu klasu DivljaŽivotinja za koju čuvamo 
i naziv lovišta u kome ih ima.
Kreirati nadglasavajuću funkciju Info()
klase DivljaŽivotinja koja osim opštih podataka
o životinji štampa i naziv lovišta.
*/


/*13. Domaci  
1. Kreirati vektor od 5 proizvoljnih objekata vaše klase. Zatim ubaciti (insertovati) novi objekat na 3 mesto,
a obrisati poslednji objekat. Odštampati rezultujući vektor na ekranu.

2. Kreirati novi objekat O1 i inicijalizovati ga podacima. Ispitati da li se u kreiranom vektoru nalazi objekat O1. Primeniti konstrukciju:
vector<VasaKlasa> vec;
… // punjenje vektora podacima prema 1.
… // ubacivanje na 3. mesto novog, brisanje poslednjeg, štampa rezultujućeg vektora.
VasaKlasa O1(…); // konstruktor treba da inicijalizuje podatke objekta
vector < VasaKlasa >::iterator it;
it = find(vec.begin(), vec.end(), O1);
Ispisati na kraju poruku o statusu (“objekat je pronađen” ili “objekat nije pronađen”).
Napomena: Da bi funkcija find mogla da ispita da li se O1 nalazi u vektoru, neophodno 
je da vaša klasa ima implementiran preklopljeni operator ==.


3.
Iz fajla “ulaz.txt” učitati N 
objekata vaše klase i spakovati ih u stek.
Zatim ih u inverznom poretku odštampati u fajl “izlaz.txt”.

*/

int main() {
	//1.
	DivljaZivotinja dz1("ime1", "b", "f", 12, 4, "suma");
	DivljaZivotinja dz2("ime2", "b", "f", 12, 32, "mocvara");
	DivljaZivotinja dz3("ime3", "b", "m", 12, 3, "planina");
	DivljaZivotinja dz4("ime4", "b", "m", 12, 1, "drvece");
	DivljaZivotinja dz5("ime5", "b", "m", 12, 2, "vazduh");


	DivljaZivotinja O1("OOO6", "grr", "m", 123, 2, "nebo");


	vector<DivljaZivotinja> vec;
	vector<DivljaZivotinja>::iterator it = vec.begin();

	vec.push_back(dz1);
	vec.push_back(dz2);
	vec.push_back(dz3);
	vec.push_back(dz4);
	vec.push_back(dz5);

	
	for (int i = 0; i < 5; i++) {
		if (i == 2) {
			vec.insert(vec.begin() + 3, dz5);
		}
		if (i == 4) {
			vec.pop_back();
		}

		cout << vec[i].info() << endl;
	}
	
	//2.

	it = find(vec.begin(), vec.end(), O1);
	if (it != vec.end()) {
		cout << "objekat je pronadjen " << endl;
	}
	else {
		cout << "objekat nije pronadjen" << endl;
	}
	
	//3.
	ifstream in;
	in.open("ulaz.txt");
	
	if (!in) {
		cout << "Doslo je do greske prilikom citanja iz fajla" << endl;
	}

	stack<DivljaZivotinja> zivotinje;

	string ime = "", zvuk = "", pol = "", loviste = "";
	int brojG = 0, brojNogu = 0;

	while (in >> ime >> zvuk >> pol >> brojNogu >> brojG >> loviste) {
		DivljaZivotinja dzz(ime, zvuk, pol, brojNogu, brojG, loviste);
		zivotinje.push(dzz);
	}
	
	in.close();

	ofstream out;
	out.open("izlaz.txt");

	if (!out) {
		cout << "Doslo je do greske prilikom upisivanja u fajl" << endl;
	}

	while (!zivotinje.empty()) {
		DivljaZivotinja d = zivotinje.top();
		
		d.operator<<(out);

		zivotinje.pop();
	}

	out.close();
	
	return 0;
}