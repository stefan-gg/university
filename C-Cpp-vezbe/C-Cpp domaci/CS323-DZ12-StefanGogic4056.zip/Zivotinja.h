#pragma once
#include <iostream>
#include <string>
using namespace std;

class Zivotinja
{
protected:
	string ime;
	string zvuk;
	int starost;
	string pol;
	int brojNogu;
public:
	Zivotinja(){}
	virtual ~Zivotinja(){}
	Zivotinja(string ime, string zvuk, string pol, int starost, int brojNogu):ime(ime), zvuk(zvuk),
		starost(starost), pol(pol), brojNogu(brojNogu){}

	virtual string info() = 0;


};

