#include "Model.h"
#include "Specifikacija.h"
#include <iostream>
#include <string.h>

Model::Model(string nazivModela, Specifikacija specifikacija) : nazivModela(nazivModela), specifikacija(specifikacija) {}

/*Model::Model(const Model& model) {
	this->nazivModela = model.nazivModela;
	this->specifikacija = model.specifikacija;
	this->specifikacija.setBrojSasije(specifikacija.getBrojSasije());
	this->specifikacija.setGodinaProizvodnje(specifikacija.getGodinaProizvodnje());
	this->specifikacija.setKaroserija(specifikacija.getKaroserija());
	this->specifikacija.setKubikaza(specifikacija.getKubikaza());
}*/

Model::~Model() {
	cout << "Objekat je unisten" << endl;
}