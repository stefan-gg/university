#include "Specifikacija.h"
#include <iostream>
#include <string.h>
using namespace std;

Specifikacija::Specifikacija(int kubikaza, int brojSasije, int godinaProizvodnje, string karoserija) : kubikaza(kubikaza), brojSasije(brojSasije), godinaProizvodnje(godinaProizvodnje), karoserija(karoserija) {}

Specifikacija::Specifikacija(const Specifikacija& spec) {
	this->kubikaza = spec.kubikaza;
	this->brojSasije = spec.brojSasije;
	this->godinaProizvodnje = spec.godinaProizvodnje;
	this->karoserija = spec.karoserija;
}

Specifikacija::~Specifikacija() {
	cout << "Objekat je unisten" << endl;
}
