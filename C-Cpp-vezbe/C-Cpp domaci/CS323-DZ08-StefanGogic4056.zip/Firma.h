#pragma once
#include <iostream>
#include <string.h>
using namespace std;

class Firma
{
private:
	string naziv;
	int godinaOsnivanja;
public:
	Firma();
	Firma(string naziv, int godinaOsnivanja);
	Firma(const Firma& f);
	~Firma();

	void setNaziv(string naziv) {
		this->naziv = naziv;
	}

	const string getNaziv() {
		return this->naziv;
	}
	
	void setGodinaOsnivanja(int godOsn) {
		this->godinaOsnivanja = godOsn;
	}

	const int getGodinaOsnivanja() {
		return this->godinaOsnivanja;
	}
};

