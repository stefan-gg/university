#pragma once
#include <iostream>
#include <string.h>
using namespace std;

class Specifikacija
{
private:
	int kubikaza;
	int brojSasije;
	int godinaProizvodnje;
	string karoserija;
public:
	Specifikacija();
	Specifikacija(int kubikaza, int brojSasije, int godinaProizvodnje, string karoserija);
	Specifikacija(const Specifikacija& spec);
	~Specifikacija();

	void setKubikaza(int kubikaza) {
		this->kubikaza = kubikaza;
	}

	const int getKubikaza() {
		return this->kubikaza;
	}

	void setBrojSasije(int brSasije) {
		this->brojSasije = brSasije;
	}

	const int getBrojSasije() {
		return this->brojSasije;
	}

	void setGodinaProizvodnje(int godProizvodnje) {
		this->godinaProizvodnje = godProizvodnje;
	}

	const int getGodinaProizvodnje() {
		return this->godinaProizvodnje;
	}

	void setKaroserija(string karoserija) {
		this->karoserija = karoserija;
	}

	const string getKaroserija() {
		return this->karoserija;
	}
};

