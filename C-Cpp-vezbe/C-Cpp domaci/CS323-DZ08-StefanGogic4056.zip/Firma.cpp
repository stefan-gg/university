#include "Firma.h"
#include <iostream>
#include <string.h>
using namespace std;

Firma::Firma(string naziv, int godinaOsnivanja) : naziv(naziv), godinaOsnivanja(godinaOsnivanja){}

Firma::Firma(const Firma& firma) {
	this->naziv = firma.naziv;
	this->godinaOsnivanja = firma.godinaOsnivanja;
}

Firma::~Firma() {
	cout << "Objekat je unisten" << endl;
}