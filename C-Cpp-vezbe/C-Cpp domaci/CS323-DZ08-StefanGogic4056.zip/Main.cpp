﻿#include <iostream>
#include "Firma.h"
#include "Model.h"
#include "Specifikacija.h"
using namespace std;

int main() {
	/*Napraviti klase na osnovu seledećeg teksta.
	Naša firma se bavi prodajom automobila i trebao bi nam 
	softver za skladištenje informacija o automobilima koje imamo na stanju.
	Ono što je nama potrebno da imamo od infromacija su koja je Firma (naziv, godina osnivanja),
	koji je Model (naziv modela, specifikacije), Koje su to specifikacije modela (kubikaza, broj šasije, godina proizvodnje i karoserija).
	Karoserija može biti : (Limunzina, Hečbek, Karavan, Kupe, Kabriolet).
	Testirati rad klasa u glavnom programu. Podatke klase smestiti u privatnoj (private)
	sekciji a metode klase (get/set metode za pristup privatnim članovima, i ostale metode)
	u javnoj (public) sekciji. Getter metode načiniti konstantnim (const).
	Deklaraciju klase smestiti u fajlu zaglavlja (npr. ImeKlase.h),
	a definicije funkcija članica klase napisati u fajlu ImeKlase.cpp.
	Za klasu kreirati podrazumevajući konstruktor, konstuktor sa parametrima i konstruktor kopiranja.
	Konstruktor sa parametrima implementirati korišćenjem pokazivača this.
	Navesti i primer konstruktora sa parametrima koji koristi listu za inicijalizaciju.
	Kreirati i destruktor klase u kome se ispisuje*/
	Firma f("1", 12);
	f.setGodinaOsnivanja(200);
	cout << f.getNaziv() << endl;

	Specifikacija s(123, 1234, 12345, "naziv");
	cout << s.getKubikaza() << endl;
	Model m("as", s);
	m.setKubikaza(999);
	cout << m.getKubikaza() << endl;

	Specifikacija s2 = s;
	cout << s2.getKubikaza() << " kopija" << endl;

	return 0;
}