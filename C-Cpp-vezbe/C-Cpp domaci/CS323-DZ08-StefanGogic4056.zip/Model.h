#pragma once
#include "Specifikacija.h"
#include <iostream>
#include <string.h>
using namespace std;

class Model
{
private:
	string nazivModela;
	Specifikacija specifikacija;
public:
	
	Model();
	Model(string nazivModela, Specifikacija specifikacija);
	//Model(const Model& model);
	~Model();

	void setNazivModela(string nazivModela) {
		this->nazivModela = nazivModela;
	}

	const string getNazivModela() {
		return this->nazivModela;
	}

	void setSpecifikacija(Specifikacija specifikacija) {
		this->specifikacija = specifikacija;
	}

	void setKubikaza(int kubikaza) {
		this->specifikacija.setKubikaza(kubikaza);
	}

	const int getKubikaza() {
		return this->specifikacija.getKubikaza();
	}

	void setBrojSasije(int brojSasije) {
		this->specifikacija.setKubikaza(brojSasije);
	}

	const int getBrojSasije() {
		return this->specifikacija.getBrojSasije();
	}

	void setGodinaProizvodnje(int godinaProizvodnje) {
		this->specifikacija.setGodinaProizvodnje(godinaProizvodnje);
	}

	const int getGodinaProizvodnje() {
		return this->specifikacija.getGodinaProizvodnje();
	}

	void setKaroserija(string karoserija) {
		this->specifikacija.setKaroserija(karoserija);
	}

	const string getKaroserija() {
		return this->specifikacija.getKaroserija();
	}
};

