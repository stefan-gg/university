#include "Warrior.h"

Warrior::Warrior() {
	this->napad = 10;
	this->odbrana = 10;
	this->iskoriscenSpecijalniPotez = false;
	this->health = 100;
}

bool Warrior::primiDmg(int dmg) {
	this->health -= dmg;
	if (this->health > 0) {
		cout << "Warrior je izgubio " << dmg << " health-a i sada ima " << this->health << " health-a." << endl;
		ofstream out;
		out.open("gubitnik.txt");

		if (!out) {
			cout << "Doslo je do greske prilikom upisivanja u fajl" << endl;
		}

		out << "Warrior je izgubio jer je njegov health iznosio manje od 0." << endl;

		out.close();
		return false;
	}
	else {
		return false;
	}
	
}

void Warrior::specijalniPotez() {
	if (this->iskoriscenSpecijalniPotez == false) {
		cout << "***************************" << endl;
		cout << "Specijalni potez Warrior-a je iskoriscen i do kraja igre njegov napad i odbrana su povecani 2 puta !!" << endl;
		cout << "***************************" << endl;
		setIskorisceniSpecijalniPotez();
		setSpecijalniNapad();
		setSpecijalnaOdbrana();
	}
	else {
		cout << "Specijalni potez ovog Warrior-a je vec iskoriscen !" << endl;
	}
	
}
