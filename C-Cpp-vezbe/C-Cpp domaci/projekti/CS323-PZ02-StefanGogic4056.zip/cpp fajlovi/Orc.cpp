#include "Orc.h"

Orc::Orc() {
	this->napad = 20;
	this->odbrana = 5;
	this->iskoriscenSpecijalniPotez = false;
	this->health = 110;
}

bool Orc::primiDmg(int dmg) {
	this->health -= dmg;
	if (this->health > 0) {
		cout << "Orc je izgubio " << dmg << " health-a i sada ima " << this->health << " health-a." << endl;
		return true;
	}
	else {
		ofstream out;
		out.open("gubitnik.txt");

		if (!out) {
			cout << "Doslo je do greske prilikom upisivanja u fajl" << endl;
		}

		out << "Orc je izgubio jer je njegov health iznosio manje od 0." << endl;

		out.close();
		return false;
	}

}

void Orc::specijalniPotez() {
	if (this->iskoriscenSpecijalniPotez == false) {
		cout << "***************************" << endl;
		cout << "Specijalni potez Orc-a je iskoriscen i do kraja igre je njegov napad povecan 4 puta !!" << endl;
		cout << "***************************" << endl;
		setIskorisceniSpecijalniPotez();
		setSpecijalniNapad();
	}
	else {
		cout << "Specijalni potez ovog Orc-a je vec iskoriscen !" << endl;
	}

}