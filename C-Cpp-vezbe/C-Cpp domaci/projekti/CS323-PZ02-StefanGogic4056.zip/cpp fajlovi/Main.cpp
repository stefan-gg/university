#include <iostream>
#include "Warrior.h"
#include "Orc.h"
#include "UnosException.h"

void stampajMeni();
void meniIzborHeroja();
int izborHeroja();
void izvrsiDmgNaWarriora(int id, int dmg, Warrior* point);
void izvrsiDmgNaOrca(int id, int dmg, Orc* poin);
void realizacijaPoteza(int idIgraca, int potez, Warrior* p, Orc* orc, Warrior* pp, Orc* orcc);
void odbranaISPecijalniPotezWarriora(int id, Warrior* point);
void odbranaISPecijalniPotezOrca(int id, Orc* poin);

int main() {
	int izborPrvog = -1, izborDrugog = -1;

	Warrior w;
	Warrior w2;
	
	Orc orc;
	Orc orc2;

	Warrior* p = NULL;
	Warrior* p2 = NULL;

	Orc* o = NULL;
	Orc* o2 = NULL;

	stack<string> opisi;

	ifstream in;
	in.open("opisi.txt");

	if (!in) {
		cout << "Doslo je do greske prilikom citanja iz fajla" << endl;
	}

	string opis = "";

	while (getline(in, opis)) {
		opisi.push(opis);
	}

	in.close();

	cout << "------------------------" << endl;
	while (!opisi.empty()) {
		cout << opisi.top() << endl;
		opisi.pop();
	}
	cout << "------------------------" << endl;

	cout << endl;
	cout << " Prvi igrac bira heroja ..." << endl;
	meniIzborHeroja();
	izborPrvog = izborHeroja();
	if (izborPrvog == 1){
		p = &w;
	}
	else if(izborPrvog == 2) {
		o = &orc;
	}
	cout << endl;
	cout << " Drugi igrac bira heroja ..." << endl;

	meniIzborHeroja();

	izborDrugog = izborHeroja();
	if (izborDrugog == 1) {
		p2 = &w2;
	}
	else if(izborDrugog == 2) {
		o2 = &orc2;
	}

	bool petlja = true;

	int i = 0;
	int izb = 0;
	while (petlja) {
		
		if (i % 2 == 0) {
			cout << endl;
			cout << "Prvi igrac sada bira potez" << endl;
			cout << endl;
		}
		else {
			cout << endl;
			cout << "Drugi igrac sada bira potez" << endl;
			cout << endl;
		}
		stampajMeni();
		cin >> izb;

		try {
			if (izb < 1 || izb > 4) {
				throw UnosException();
			}
		}
		catch (UnosException& e) {
			cout << e.what() << endl;
			continue;
		}
		catch (exception& e) {
			cout << "Doslo je do greske" << endl;
			continue;
		}

		if (izb == 4) {
			cout << "Igra je zavrsena pre vremena jer je jedan od igraca uneo broj 4 !" << endl;
			break;
		}

		if (i % 2 == 0) {
			if (izb == 1) {
				realizacijaPoteza(i, izb, p, o, p2, o2);
				if (p2 != NULL && p2->getHealth() < 1) {
					cout << "Kraj igre !! Imamo pobednika !! Prvi igrac je pobedio !!!" << endl;
					break;
				}
				else if (o2 != NULL && o2->getHealth() < 1) {
					cout << "Kraj igre !! Imamo pobednika !! Prvi igrac je pobedio !!!" << endl;
					break;
				}
				i++;
			}
			else {
				if (o != NULL) {
					odbranaISPecijalniPotezOrca(izb , o);
				}
				else {
					odbranaISPecijalniPotezWarriora(izb, p);
				}
				i++;
			}
		}
		else {
			if (izb == 1) {
				realizacijaPoteza(i, izb, p, o, p2, o2);
				if (p != NULL && p->getHealth() < 1) {
					cout << "Kraj igre !! Imamo pobednika !! Drugi igrac je pobedio !!!" << endl;
					break;
				}
				else if (o != NULL && o->getHealth() < 1) {
					cout << "Kraj igre !! Imamo pobednika !! Drugi igrac je pobedio !!!" << endl;
					break;
				}
				i++;
			}
			else {
				if (o2 != NULL) {
					odbranaISPecijalniPotezOrca(izb, o2);
				}
				else {
					odbranaISPecijalniPotezWarriora(izb, p2);
				}
				i++;
			}
		}
		
	}
	return 0;
}

void stampajMeni() {
	cout << endl;
	cout << "Izaberite neku od sledecih opcija : " << endl;
	cout << "1 - Napad " << endl;
	cout << "2 - Odbrana " << endl;
	cout << "3 - Specijalni potez(moze da se iskoristi samo jednom u toku igre) " << endl;
	cout << "4 - Kraj igre" << endl;
	cout << endl;
}

void meniIzborHeroja() {
	cout << endl;
	cout << "Izaberite nekog od sledecih heroja : " << endl;
	cout << "1 - Warrior " << endl;
	cout << "2 - Orc " << endl;
	cout << endl;
}

int izborHeroja() {
	try {
		int izbor = 0;

		cin >> izbor;
	
		if (izbor == 1) {
			return 1;
		}
		else if (izbor == 2) {
			return 2;
		}
		else {
			throw UnosException();
		}
	}
	catch (UnosException& e) {
		cout << e.what() << " Zbog nevazece vrednosti po default-u je izabran Warrior !" << endl;
		return 1;
	}	
}

void realizacijaPoteza(int idIgraca, int potez, Warrior* p, Orc* orc, Warrior* pp, Orc* orcc) {
	if (idIgraca % 2 == 0) {
		if (potez == 1) {
			if (p != NULL && orcc != NULL) {
				izvrsiDmgNaOrca(potez, p->getDmg(), orcc);
			}
			else if (p != NULL && pp != NULL) {
				izvrsiDmgNaWarriora(potez, p->getDmg(), pp);
			}
			else if (orc != NULL && orcc != NULL) {
				izvrsiDmgNaOrca(potez, orc->getDmg(), orcc);
			}
			else if (orc != NULL && pp != NULL) {
				izvrsiDmgNaWarriora(potez, orc->getDmg(), pp);
			}
		}
	}
	else {
		if (potez == 1) {
			if (p != NULL && orcc != NULL) {
				izvrsiDmgNaWarriora(potez, orcc->getDmg(), p);
			}
			else if (p != NULL && pp != NULL) {
				izvrsiDmgNaWarriora(potez, pp->getDmg(), p);
			}
			else if (orc != NULL && orcc != NULL) {
				izvrsiDmgNaOrca(potez, orcc->getDmg(), orc);
			}
			else if (orc != NULL && pp != NULL) {
				izvrsiDmgNaOrca(potez, pp->getDmg(), orc);
			}
		}
	}
}

void izvrsiDmgNaWarriora(int id, int dmg, Warrior* point) {
	if (id == 1) {
		point->primiDmg(dmg);
	}
}

void izvrsiDmgNaOrca(int id, int dmg, Orc* poin) {
	if (id == 1) {
		poin->primiDmg(dmg);
	}
}

void odbranaISPecijalniPotezWarriora(int id, Warrior* point) {
	if (id == 2) {
		cout << "Warrior se brani ovog poteza." << endl;
		point->setOdbrana();
	}
	else {
		point->specijalniPotez();
	}
}

void odbranaISPecijalniPotezOrca(int id, Orc* poin) {
	if (id == 2) {
		cout << "Warrior se brani ovog poteza." << endl;
		poin->setOdbrana();
	}
	else {
		poin->specijalniPotez();
	}
}