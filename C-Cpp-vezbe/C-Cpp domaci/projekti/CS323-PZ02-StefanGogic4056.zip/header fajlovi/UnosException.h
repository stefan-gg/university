#pragma once
#include "Hero.h"
class UnosException : public exception
{
public:
	virtual const char* what() const noexcept {
		return "Uneta je nevazeca vrednost !!!";
	}
};

