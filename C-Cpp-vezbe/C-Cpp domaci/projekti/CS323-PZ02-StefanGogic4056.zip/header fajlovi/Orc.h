#pragma once
#include "Hero.h"

class Orc : protected Hero
{
public :
	Orc();

	virtual ~Orc() {}

	void setIskorisceniSpecijalniPotez() {
		this->iskoriscenSpecijalniPotez = true;
	}

	void setOdbrana() {
		this->health += this->odbrana;
	}

	void setSpecijalniNapad() {
		this->napad = this->napad * 4;
	}

	int getDmg() const {
		return this->napad;
	}

	int getHealth() const {
		return this->health;
	}

	bool primiDmg(int dmg);

	virtual void specijalniPotez();
};

