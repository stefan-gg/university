#pragma once
#include "Hero.h"

class Warrior : public Hero
{
public:

	Warrior();

	virtual ~Warrior(){}

	void setIskorisceniSpecijalniPotez() {
		this->iskoriscenSpecijalniPotez = true;
	}
	
	void setOdbrana() {
		this->health += this->odbrana;
	}

	void setSpecijalniNapad() {
		this->napad = this->napad * 2;
	}

	void setSpecijalnaOdbrana() {
		this->odbrana = this->odbrana * 2;
	}

	int getDmg() const {
		return this->napad;
	}

	int getHealth() const{
		return this->health;
	}

	bool primiDmg(int dmg);

	virtual void specijalniPotez();
};

