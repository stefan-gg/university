#pragma once
#include <iostream>
#include <fstream>
#include <exception>
#include <stack>
#include<cstdlib>
#include <string>

using namespace std;

class Hero
{
protected:
	int napad;
	int odbrana;
	int health;
	bool iskoriscenSpecijalniPotez;
public:
	Hero() {}
	virtual void specijalniPotez() = 0;
	virtual ~Hero() {}
};

