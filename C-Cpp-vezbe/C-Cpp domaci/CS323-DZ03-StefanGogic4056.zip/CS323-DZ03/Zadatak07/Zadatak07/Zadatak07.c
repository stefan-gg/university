﻿#include <stdio.h>
#define brojElemenata 10

pozitivniOd(int niz[], int brojUnetihElemenata) {
	int i = 0;
	int brojacPozitivnih = 0;
	for (; i < brojUnetihElemenata; i++)
	{
		for (int j = i; j < brojUnetihElemenata; j++)
		{
			if (niz[j] > 0) {
				brojacPozitivnih++;
			}
		}
		niz[i] = brojacPozitivnih;
		brojacPozitivnih = 0;
	}
	i = 0;
	for (; i < brojUnetihElemenata; i++)
	{
		printf("\n%d", niz[i]);
	}
}

void main(void) {
	int izabraniBroj = 0, brojUnetihElemenata = 0;
	int niz[brojElemenata];

	printf("Unesite broj elemenata niza(vrednost između 1 i 10) : \n");
	scanf("%d", &izabraniBroj);
	if (izabraniBroj < 0 || izabraniBroj > brojElemenata) {
		printf("Niste uneli ispravnu vrednost za veličinu");
	}
	int i = 0;
	for (; i < izabraniBroj; i++)
	{
		scanf("%d", &niz[i]);
	}

	brojUnetihElemenata = izabraniBroj;

	pozitivniOd(niz, brojUnetihElemenata);
}