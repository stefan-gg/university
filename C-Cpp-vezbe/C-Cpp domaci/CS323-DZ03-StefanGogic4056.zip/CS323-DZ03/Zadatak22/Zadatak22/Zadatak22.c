#include <stdio.h>
#include <string.h>
#define _CRT_SECURE_NO_WARNINGS
#define brojSlova 20

palindrom(char string[]) {
	int brojSlovaUStringu = 0, sredisnjeSlovo, nepodudaranje = 0;
	brojSlovaUStringu = strlen(string);
	
	if (brojSlovaUStringu % 2 != 0) {
		sredisnjeSlovo = (brojSlovaUStringu - 1) / 2;
		sredisnjeSlovo += 1;
	}
	else {
		sredisnjeSlovo = brojSlovaUStringu / 2;
	}

	int i = 0;
	int j = brojSlovaUStringu - 1;

	for (;i < brojSlovaUStringu - 1 && j >= 0; i++, j--)
	{
		//for (; j >= 0; j--)
		//{
		if (string[i] != string[j]) {
				//printf("String nije palindrom.");
				//printf("\n%d i", i);
				//printf("\n%d j", j);
			nepodudaranje++;
		}
			
		//}
	}
	if (nepodudaranje == 0) {
		printf("String koji je unet je palindrom.");
	}
	if (nepodudaranje != 0) {
		printf("String koji je unet nije palindrom.");
	}
}

void main(void) {
	printf("Unesite string za koji mislite da je palindrom : \n");
	char string[brojSlova];
	gets(string);

	palindrom(string);
}