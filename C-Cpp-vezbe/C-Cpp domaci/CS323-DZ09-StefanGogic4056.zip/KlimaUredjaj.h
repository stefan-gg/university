#pragma once
#include <iostream>
#include <cstring>
using namespace std;

class KlimaUredjaj
{
private:
	char* ime;
	char* barKod;
	char* sifra;
	int cena;
	char* tip;
	int jacinaKlime;
	static int brojac;
public:
	KlimaUredjaj(){}
	KlimaUredjaj(const char* i,const char* bK,const char* s,const int cen,const char* t,const int jacinaKlim);
	~KlimaUredjaj();

	bool operator>(const KlimaUredjaj& ku);

	bool operator<(const KlimaUredjaj& ku);

	bool operator==(const KlimaUredjaj& ku);

	friend ostream& operator<<(ostream& out, const KlimaUredjaj& a);
	friend istream& operator>>(istream& in, KlimaUredjaj& a);

	static int getBrojObjekata();

	void setSifra(char* i) {
		this->sifra = new char[strlen(i) + 1];
		strcpy(sifra, i);
	}

	friend void setSifraa(KlimaUredjaj& c, char* i);

	const char* getSifra()const {
		return sifra;
	}

	void setTip(char* i) {
		this->tip = new char[strlen(i) + 1];
		strcpy(tip, i);
	}

	friend void setTipp(KlimaUredjaj& c, char* i);

	const char* getTip()const {
		return tip;
	}

	void setBarKod(char* i) {
		this->barKod = new char[strlen(i) + 1];
		strcpy(barKod, i);
	}

	friend void setBarKodd(KlimaUredjaj& c, char* i);

	const char* getBarKod()const {
		return barKod;
	}

	void setIme(char* i) {
		this->ime = new char[strlen(i) + 1];
		strcpy(ime, i);
	}
	
	friend void setImee(KlimaUredjaj& c, char* i);

	const char* getIme()const {
		return ime;
	}

	void setCena(int cena) {
		this->cena = cena;
	}

	friend void setCenaa(KlimaUredjaj& c, int cena);

	int getCena() {
		return this->cena;
	}

	void setJacinaKlime(int jacinaKlime) {
		this->jacinaKlime = jacinaKlime;
	}

	friend void setJacinaKlimee(KlimaUredjaj& c, int jacinaKlime);

	int getJacinaKlime() {
		return this->jacinaKlime;
	}

	
};

