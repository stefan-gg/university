#include "KlimaUredjaj.h"

int KlimaUredjaj::brojac = 0;

KlimaUredjaj::KlimaUredjaj(const char* i,const char* bK,const char* s,const int cen,const char* t,const int jacinaKlim) {
	ime = new char[strlen(i) + 1];
	strcpy(ime, i);

	barKod = new char[strlen(bK) + 1];
	strcpy(barKod, bK);

	sifra = new char[strlen(s) + 1];
	strcpy(sifra, s);

	tip = new char[strlen(t) + 1];
	strcpy(tip, t);

	this->cena = cen;
	this->jacinaKlime = jacinaKlim;

	brojac++;
}

ostream& operator<<(ostream& out, const KlimaUredjaj& a) {
	out << a.barKod << a.cena << a.ime << a.tip << a.sifra << a.jacinaKlime << endl;
	return out;
}

istream& operator>>(istream& in, KlimaUredjaj& a) {
	in >> a.barKod >> a.cena >> a.ime >> a.tip >> a.sifra >> a.jacinaKlime;
	return in;
}

bool KlimaUredjaj::operator>(const KlimaUredjaj& ku) {
	if (this->jacinaKlime > ku.jacinaKlime) {
		return true;
	}
	return false;
}

bool KlimaUredjaj::operator<(const KlimaUredjaj& ku) {
	if (this->jacinaKlime < ku.jacinaKlime) {
		return true;
	}
	return false;
}

bool KlimaUredjaj::operator==(const KlimaUredjaj& ku) {
	if (this->jacinaKlime == ku.jacinaKlime) {
		return true;
	}
	return false;
}

int KlimaUredjaj::getBrojObjekata() {
	return brojac;
}

void setImee(KlimaUredjaj& c, char* i) {
	c.ime = new char[strlen(i) + 1];
	strcpy(c.ime, i);
}

void setCenaa(KlimaUredjaj& c, int cena) {
	c.cena = cena;
}

void setSifraa(KlimaUredjaj& c, char* sifraa) {
	c.sifra = sifraa;
}

void setTipp(KlimaUredjaj& c, char* tipp) {
	c.tip = tipp;
}

void setBarKodd(KlimaUredjaj& c, char* barKodd) {
	c.barKod = barKodd;
}

void setJacinaKlimee(KlimaUredjaj& c, int jacinaKlime) {
	c.jacinaKlime = jacinaKlime;
}

KlimaUredjaj::~KlimaUredjaj() {
	delete[] ime;
	delete[] barKod;
	delete[] sifra;
	delete[] tip;
	cout << "destr" << endl;
	brojac--;
}