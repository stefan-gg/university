﻿#include "KlimaUredjaj.h"

//using namespace std;

/*Napraviti implementaciju modela u C++-u za sledeći primer: Naša firma prodaje klima uređaje.
Treba nam program koji pamti o svim proizvodima koje nudimo: ime, bar kod, šifra, cena, tip, jačina klime. 
U glavnoj main funkciji kreirati niz od N klima uređaja, i ispisati podatke o onoj klimi čiji je proizvođac Philips a cena najmanja.
Podatke klase smestiti u privatnoj (private) sekciji a metode klase (get/set metode za pristup privatnim članovima, i ostale metode) 
u javnoj (public) sekciji. Kreirati i prijateljske funkcije koje imaju ulogu setter metoda.
Deklaraciju klase smestiti u fajlu zaglavlja(npr. ImeKlase.h), a definiciju funkcija članica klase smestiti u fajlu ImeKlase.cpp.
Glavni program napisati u main.cpp fajlu.
Kreirati statički podatak (u sekciji private) koji ce da sluzi kao informacija o broju kreiranih objekata.
Kreirati i destruktor u kome se ovaj statički podatak umanjuje za jedan pri unistavanju objekta.
Kreirati staticku funkciju getBrojObjekata koja pristupa ovom statičkom podatku 
i štampa informaciju o trenutnom broju kreiranih objekata.
Kreirati preklopljene operatore poređenja (samo <, > i ==) objekata klase .
Kreirati i preklopljene operatore koje omogućavaju učitavanje (>>) odnosno štampanje objekata (<<) na ekran.*/


int main() {
	char niz[] = "SAMSUNG", nizDrugi[] = "Philips";
	int i, min = 100000;
    KlimaUredjaj uredjaji[10];
	
	uredjaji[0].setIme(niz);
	uredjaji[0].setCena(1032);

	uredjaji[1].setIme(nizDrugi);
	uredjaji[1].setCena(112);

	uredjaji[2].setIme(niz);
	uredjaji[2].setCena(111);

	uredjaji[3].setIme(nizDrugi);
	uredjaji[3].setCena(111);


	for (i = 0; i < 4; i++){
		if (strcmp(uredjaji[i].getIme(), "Philips") == 0) {
			if (uredjaji[i].getCena() < min) {
				min = uredjaji[i].getCena();
			}
		}
	}

	for (i = 0; i < 20; i++) {
		if (uredjaji[i].getCena() == min && strcmp(uredjaji[i].getIme(), "Philips") == 0) {
			cout << uredjaji[i].getIme() << " " << uredjaji[i].getCena() << endl;
		}
	}

	return 0;
}