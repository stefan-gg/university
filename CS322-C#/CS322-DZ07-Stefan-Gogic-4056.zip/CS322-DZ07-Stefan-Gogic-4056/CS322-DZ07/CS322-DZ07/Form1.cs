﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Windows.Forms;

namespace CS322_DZ07
{
	public partial class Form1 : Form
	{

		private static string mySqlConnectionString = "datasource=localhost;port=3306;username=root;passowrd=;Integrated Security=True;";
		private static string databaseName = "users";
		private static string databaseQuery = "CREATE DATABASE IF NOT EXISTS " + databaseName + ";";
		private static string createQuery =
			" CREATE TABLE IF NOT EXISTS " + databaseName + ".user(" +
			" id INT NOT NULL AUTO_INCREMENT," +
			" ime VARCHAR(127) NOT NULL," +
			" prezime VARCHAR(127) NOT NULL," +
			" datum_rodjenja VARCHAR(127) NOT NULL," +
			" pol VARCHAR(127) NOT NULL," +
			" student BOOLEAN NOT NULL," +
			" PRIMARY KEY (id)" +
			" );";

		private MySqlConnection mySqlConnection;
		private MySqlDataAdapter mySqlDataAdapter;

		public Form1()
		{
			InitializeComponent();

			mySqlConnection = new MySqlConnection(mySqlConnectionString);
			izvrsiUpit(mySqlConnection, databaseQuery);
			izvrsiUpit(mySqlConnection, createQuery);
		}

		private void label1_Click(object sender, EventArgs e)
		{

		}

		private void radioButton1_CheckedChanged(object sender, EventArgs e)
		{

		}

		private void izvrsiUpit(MySqlConnection connection, string query)
		{
			MySqlCommand mySqlCommand = new MySqlCommand(query, connection);
			try
			{
				connection.Open();
				mySqlCommand.ExecuteNonQuery();
				connection.Close();
				MessageBox.Show("Upit je executovan uspesno");
			}
			catch (Exception ex)
			{
				connection.Close();
				MessageBox.Show("Desila se greska !");
			}
		}

		private void button1_Click(object sender, EventArgs e)
		{
			string ime = textBox1.Text;
			string prezime = textBox2.Text;
			string datumRodjenja = textBox3.Text;
			bool muski = radioButton1.Checked;
			bool zenski = radioButton2.Checked;

			MessageBox.Show(checkBox1.Text);

			int student = checkBox1.Checked == true ? 1 : 0;

			if (ime.Length == 0 || prezime.Length == 0 || datumRodjenja.Length == 0)
			{
				MessageBox.Show("Sva polja moraju da se popune");
				return;
			}

			string pol = (radioButton1.Checked == true) ? "musko" : "zensko";

			string query = "INSERT INTO " + databaseName + ".user(ime, prezime, datum_rodjenja, pol, student) " +
				"VALUES ('" + ime + "', '" + prezime + "', '" + datumRodjenja + "', '" 
				+ pol + "', '" + student + "');";
			izvrsiUpit(mySqlConnection, query);
			MessageBox.Show("Uspesno kreiran korisnik!");
		}

		private void button2_Click(object sender, EventArgs e)
		{
			mySqlConnection.Open();
			mySqlDataAdapter = new MySqlDataAdapter();
			string query = "SELECT * FROM " + databaseName + ".user as u;";
			mySqlDataAdapter.SelectCommand = new MySqlCommand(query, mySqlConnection);

			DataTable table = new DataTable();
			mySqlDataAdapter.Fill(table);

			BindingSource bs = new BindingSource();
			bs.DataSource = table;

			dataGridView1.DataSource = bs;
			dataGridView1.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
			dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

			mySqlConnection.Close();
		}
	}
}
