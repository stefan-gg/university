﻿#include "FizickoLice.h"
#include "Kafa.h"
/*7. zadatak
Naša firma trenutno čuva informacije o zaposlenim licima.
Opšti podaci koje čuvamo u klasi Lice trenutno su: ime, prezime,
adresa kao i broj telefona. Klasa Lice treba da sadrži i funkciju
Info() koja štampa broj telefona. Kreirati izvedenu klasu FizickoLice za
koje čuvamo još i broj lične karte. Kreirati nadglasavajuću funkciju Info() 
klase FizickoLice koja osim opštih podataka o Licu štampa i broj lične karte.
*/

/*17. zadatak
Napraviti program na osnovu sledećeg teksta: 
Naša firma se bavi proizvodnjom prehrambrenih proizvoda.
O svim proizvodima čuvamo sledeće informacije: 
Ime proizvoda, cena proizvoda, rok trajanja.
Klasa Proizvod treba da sadrži i funkciju Info()
koja štampa sve podatke o proizvodu. Jedna od kategorija mogu biti i Kafe.
Kod kafe čuvamo i podataka da li je u zrnu ili je samlevena.
Klasa Kafe treba da sadrži i funkciju Info() koja osim svih podataka o proizvodu štampa 
i podatak o tipu kafe. Kod opstih proizvoda PDV je 20% dok je za Kafe PDV na cenu 12%.
*/

void main() {
	//7. zadatak
	Lice l;
	l.setBrojTelefona("1233");

	FizickoLice fl;

	fl.setBrojLicneKarte(1233123);
	fl.setBrojTelefona("2112332");

	l.Info();
	fl.Info();

	//17. zadatak
	Proizvod p;
	p.setCenaProizvoda(100);
	p.setImeProizvoda("proizvod");
	p.setRokTrajanja("12-12-12");

	Kafa kafa;
	kafa.setSamlevena(true);
	kafa.setImeProizvoda("kafa");
	kafa.setCenaProizvoda(200);
	kafa.setRokTrajanja("12-12-12");
	kafa.setZrno(false);

	p.Info();
	kafa.Info();
}