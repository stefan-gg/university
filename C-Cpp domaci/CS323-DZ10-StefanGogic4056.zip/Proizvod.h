#pragma once
#include <iostream>
using namespace std;
class Proizvod
{
	//17.zadatak
protected:
	string imeProizvoda;
	float cenaProizvoda;
	string sRokTrajanja;

public:
	Proizvod() {};
	~Proizvod() {};

	void setImeProizvoda(string ime) {
		this->imeProizvoda = ime;
	}

	string getImeProizvoda()const {
		return this->imeProizvoda;
	}

	void setCenaProizvoda(int cena) {
		this->cenaProizvoda = cena + cena * 0.20;
	}

	float getCenaProizvoda()const {
		return this->cenaProizvoda;
	}

	void setRokTrajanja(string rok) {
		this->sRokTrajanja = rok;
	}

	string getRokTrajanja()const {
		return this->sRokTrajanja;
	}

	void Info() {
		cout << "Proizvod: ime->"<< this->imeProizvoda << ", cena->" << this->cenaProizvoda << ", rok trajanja->" << this->sRokTrajanja << endl;
	}
};

