#pragma once
#include "Lice.h"
class FizickoLice : public Lice {
	//7.zadatak
private:
	int brojLicneKarte;

public:
	FizickoLice() {};
	~FizickoLice() {};

	void setBrojTelefona(string broj) {
		this->sBrojTelefona = broj;
	}

	string getBrojTelefona() {
		return this->sBrojTelefona;
	}

	void setBrojLicneKarte(int brojLKarte) {
		this->brojLicneKarte = brojLKarte;
	}

	int getBrojLicneKarte()const {
		return this->brojLicneKarte;
	}

	void Info() {
		cout << "Fizicko lice : broj licne karte : " << this->brojLicneKarte << ", broj telefona : " << this->sBrojTelefona << endl;
	}
};
