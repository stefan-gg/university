#pragma once
#include <iostream>
using namespace std;
class Lice
{
	//7.zadatak
protected:
	string ime;
	string prezime;
	string adresa;
	string sBrojTelefona;
public:
	Lice() {};
	~Lice() {};

	void setBrojTelefona(string broj) {
		this->sBrojTelefona = broj;
	}

	string getBrojTelefona()const {
		return this->sBrojTelefona;
	}

	void Info() {
		cout << "Lice: broj telefona : " << this->sBrojTelefona << endl;
	}
};

