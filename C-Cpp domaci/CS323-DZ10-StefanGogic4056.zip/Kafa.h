#pragma once
#include "Proizvod.h"
class Kafa : public Proizvod
{
	//17. zadatak
private:
	bool zrno;
	bool samlevena;

public:
	Kafa() {};
	~Kafa() {};

	void setZrno(bool zrno) {
		this->zrno = zrno;
	}

	bool getZrno()const {
		return this->zrno;
	}

	void setSamlevena(bool samlevena) {
		this->samlevena = samlevena;
	}

	bool getSamlevena()const {
		return this->samlevena;
	}

	void setImeProizvoda(string ime) {
		this->imeProizvoda = ime;
	}

	string getImeProizvoda()const {
		return this->imeProizvoda;
	}

	void setCenaProizvoda(float cena) {
		this->cenaProizvoda = cena + cena * 0.12;
	}

	float getCenaProizvoda()const {
		return this->cenaProizvoda;
	}

	void setRokTrajanja(string rok) {
		this->sRokTrajanja = rok;
	}

	string getRokTrajanja()const {
		return this->sRokTrajanja;
	}

	void Info() {
		cout << "Kafa: ime->" << this->imeProizvoda << ", cena->" << this->cenaProizvoda << ", rok trajanja->" <<
			this->sRokTrajanja << ", samlevena->" << this->samlevena << ", zrno->" << this->zrno << endl;
	}
};

