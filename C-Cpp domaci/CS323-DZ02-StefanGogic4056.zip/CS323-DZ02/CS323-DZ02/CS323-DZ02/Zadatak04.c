#include <stdio.h>

void main(void) {
	int a, b, f;

	printf("Unesite vrednost broja a :");
	scanf("%d", &a);
	printf("Unesite vrednost broja b :");
	scanf("%d", &b);

	if (a % 2 != 0) {
		f = a + b;
		printf("a je neparno i rezultat je : %d", f);
	}
	else
	{
		f = a * b;
		printf("a je parno i rezultat je : %d", f);
	}
}