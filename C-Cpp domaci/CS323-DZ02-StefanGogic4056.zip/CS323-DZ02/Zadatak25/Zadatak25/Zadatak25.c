#include <stdio.h>

int cifra(int d, int n);

void main(void) {

	int cifraa, broj, rezultat = 0;

	printf("Unesite neki jednocifreni broj : ");
	scanf("%d", &cifraa);
	printf("Unesite neki broj : ");
	scanf("%d", &broj);

	while (cifraa >= 10) {
		cifraa = cifraa / 10;
	}

	rezultat = cifra(cifraa, broj);
	
	if (rezultat == 0) {
		printf("U unetom broju se ne nalazi cifra %d", cifraa);
	}
	else
	{
		printf("U unetom broju se nalazi cifra %d", cifraa);
	}
}

int cifra(int d, int n) {
	int trenutnaCifra = 0;
	do
	{
		trenutnaCifra = n % 10;
		n = n / 10;
		if (trenutnaCifra == d) {
			return 1;
		}
	} while (n != 0);
	return 0;
}