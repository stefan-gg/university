﻿#include <stdio.h>
#include <string.h>

#define MAX 10

/*
Definisati strukturu roditelj koja sadrži sledeće podatke: ime roditelja, ime deteta. 
Program sadrži funkciju Broj dece koja za ime roditelja koje joj je prosleđeno pri 
pozivu vraća koliko taj roditelj ima dece.
U glavnom programu učitati podatke o roditeljima i ispisati ime roditelja sa najvećim brojem dece
(ako ih ima više ispisati sva imena).
*/

typedef struct 
{
	char imeRoditelja[30];
	char imeDeteta[30];
} Roditelj;

int brojDece(char* imeRoditeljaDeteta, Roditelj roditelj[]) {

	Roditelj r;

	strcpy(r.imeRoditelja, imeRoditeljaDeteta);

	int i, countBrojDece = 0, compare;

	for (i = 0; i < MAX; i++) {
		compare = strcmp(roditelj[i].imeRoditelja, r.imeRoditelja);
		if (compare == 0) {
			countBrojDece++;
		}
	}

	return countBrojDece;
}

void main() {
	
	char ime[30] = "Nenad";
	int i = 0, max = 0, broj = 0;

	Roditelj roditelj[MAX];
	
	strcpy((roditelj[0].imeRoditelja), "Nenad");
	strcpy((roditelj[1].imeRoditelja), "Nenad");
	strcpy((roditelj[2].imeRoditelja), "Nenad");
	strcpy((roditelj[3].imeRoditelja), "Nenad");
	strcpy((roditelj[4].imeRoditelja), "Nenad");
	strcpy((roditelj[5].imeRoditelja), "Nenad");
	strcpy((roditelj[6].imeRoditelja), "Nenad");
	strcpy((roditelj[7].imeRoditelja), "Nenad");
	strcpy((roditelj[8].imeRoditelja), "Nenad");
	strcpy((roditelj[9].imeRoditelja), "Mihajlo");

	strcpy((roditelj[0].imeDeteta), "Nenad");
	strcpy((roditelj[1].imeDeteta), "Nenad");
	strcpy((roditelj[2].imeDeteta), "Nenad");
	strcpy((roditelj[3].imeDeteta), "Nenad");
	strcpy((roditelj[4].imeDeteta), "Nenad");
	strcpy((roditelj[5].imeDeteta), "Nenad");
	strcpy((roditelj[6].imeDeteta), "Nenad");
	strcpy((roditelj[7].imeDeteta), "Nenad");
	strcpy((roditelj[8].imeDeteta), "Nenad");
	strcpy((roditelj[9].imeDeteta), "Nenad");

	i = brojDece(&ime, roditelj);
	printf("Broj dece za ime : %s %d \n", ime, i);

	for (size_t i = 0; i < MAX; i++)
	{
		broj = brojDece(roditelj[i].imeRoditelja, roditelj);
		if (broj > max) {
			max = broj;
		}
	}

	for (size_t i = 0; i < MAX; i++)
	{
		broj = brojDece(roditelj[i].imeRoditelja, roditelj);
		if (broj == max) {
			printf("Roditelj sa najvise dece : %s \n", roditelj[i].imeRoditelja);
		}
	}

}