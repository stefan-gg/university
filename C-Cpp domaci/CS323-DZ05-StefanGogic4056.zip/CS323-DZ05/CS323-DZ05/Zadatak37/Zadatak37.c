﻿#include <stdio.h>

#define MAX 20

/*Napisati funkciju kojom se izbacuju sve praznine u učitanom stringu.
Novodobijeni string formirati kao dinamički niz u okviru funkcije, a zatim ga vratiti u glavni program.
Testirati rad funkcije u glavnom programu.*/

char* izbaciPraznine(char* niz) {

	int count = 0, j, i;
	char* nizBezRazmaka;

	for (i = 0; i < MAX; i++)
	{
		if (niz[i] != ' ') {
			count++;
		}
	}

	nizBezRazmaka = malloc(count * sizeof(char));

	for (i = 0, j = 0; i < MAX; i++)
	{
		if (niz[i] != ' ') {
			nizBezRazmaka[j] = niz[i];
			j++;
		}
	}

	return nizBezRazmaka;
}


void main(void) {
	int count = 0, i;
	char* p;
	char niz[MAX] = {"1234567890- 1223 1 1"};

	//ovo sam našao na internetu ispod se nalazi link za stranicu ali sam stavio pod komentar zato što to nije moje rešenje
	//takođe sam ograničio da može da primi samo 19 karaktera zato što je zadnje mesto rezervisano za '\0'
	//https://www.geeksforgeeks.org/taking-string-input-space-c-3-different-methods/
	//scanf("%19[^\n]%*c", niz);

	p = izbaciPraznine(&niz);

	for (i = 0; i < MAX; i++)
	{
		if (niz[i] != ' ') {
			count++;
		}
	}

	for (i = 0; i < count; i++)
	{
		printf("%c", p[i]);
	}

	free(p);
}


