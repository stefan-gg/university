﻿#include <iostream>
#include <iomanip>  

using namespace std;

/*[C++]: Učitati vrednosti za celobrojne promenjive a, b i c, pa prikazati sledeću poruku na ekranu:
a = ____ kg. b = ____ m. c = ____ din.*/

void main() {
	int a;
	int b;
	int c;

	cout << "Unesite a :" << endl;
	cin >> a;
	cout << "Unesite b :" << endl;
	cin >> b;
	cout << "Unesite c :" << endl;
	cin >> c;

	cout << "a = " << a << " kg" << endl;
	cout << "b = " << setprecision(5) << b << " m" << endl;
	cout << "c = " << setw(10) << c << " din" << endl;
}