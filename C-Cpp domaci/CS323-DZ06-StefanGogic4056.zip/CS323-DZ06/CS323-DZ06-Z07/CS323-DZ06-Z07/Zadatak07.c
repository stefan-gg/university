﻿#include <stdio.h>


/*Napisati program koji kao parametar pri startovanju programa dobija imena ulazne i izlazne datoteke.
U ulaznoj datoteci se nalaze celi brojevi (svi brojevi su manji od 1000).
U izlaznu datoteku prepisati brojeve iz ulazne datoteke koji su neparni i veći od nule.*/

int main(int argc, char* argv[])
{
	FILE* in,* out;
	int x;
	
	if (argc != 3) {
		fprintf(stderr, "Upotreba: %s ulazna izlazna", argv[0]); 
		return 1;
	}

	in = fopen(argv[1], "r");
	
	if (in == NULL) 
	{
		printf("Doslo je do greske prilikom otvaranja fajla %s", argv[1]);
		return -1;
	}

	out = fopen(argv[2], "w");
	if (out == NULL)
	{
		printf("Doslo je do greske prilikom rada sa fajlom : %s", argv[2]);
		return -1;
	}

	printf("Brojevi koji se nalaze u fajlu su : ");
	while (fscanf(in, "%d", &x) == 1) {
		printf("%d ", x);
		if (x > 0 && x < 999 && x % 2 != 0) {
			fprintf(out, "%d", x);
			fprintf(out, "%s", "\n");
		}
	}
	fclose(in);
	fclose(out);

	return(0);
}