#include <iostream>
#include <string>

/*C++ string klasa: Napisati program koji izbacuje sve nule na kraju
C++ stringa i pokazuje dobijeni rezultat.
Napomena - Koristiti funkcije C++ klase za rad sa stringovima ( find, replace,insert�) .*/

using namespace std;
void main() {
	int i, count = 0, pocetak = 0;
	string rec = "Ova rec sadrzi nule na kraju 000000....";

	cout << rec.length() << endl;

	for (i = rec.length(); i > 0; i--) {
		if (rec[i] == '0') {
			count++;
			pocetak = i;
		}
		if (rec[i - 1] != '0' && rec[i] == '0') {		
			rec.erase(pocetak, count);
			cout << "String bez nula na kraju : " << rec << endl;
			break;
		}
	}
	
}