#include <iostream>
#include <fstream>
#include "Test.h"
using namespace std;

namespace Test {
	void nalazi(int a[], int n, int x, int& rez) {
		int i, lokacija = -1, count = 0;

		for (i = 0; i < n; i++)
		{
			if (a[i] == x && count == 0) {
				lokacija = i;
				count++;
			}
		}

		rez = lokacija;

	}
}