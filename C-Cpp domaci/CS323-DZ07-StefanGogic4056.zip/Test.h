#pragma once
namespace Test {
	void nalazi(int a[], int n, int x, int& rez);
}

