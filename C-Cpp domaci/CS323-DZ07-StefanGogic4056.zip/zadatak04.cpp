﻿/*#include <iostream>
#include <fstream>
#include "Test.h"
using namespace std;
using namespace Test;*/

/*C++ program: Napisati funkciju
void nalazi(int a[], int n, int x, int& rez)
kojom se proverava da li se element x nalazi u nizu a duzine n.
Promenljiva rez treba da bude -1 ukoliko se element ne nalazi u nizu tj.
indeks prvog pojavljivanja elementa ako se element nalazi u nizu.
U glavnom programu učitati dimenziju niza (n < 20) i elemente niza iz fajla „ulaz.txt“
korišćenjem C++ tokova za rad sa fajlovima i testirati rad funkcije.
Funkciju ubaci kreirati kao deo imenskog prostora Test, u posebnom fajlu Test.cpp.
Niz kreirati kao dinamički niz (dinamičko upravljanje memorijom u programskom jeziku C++).*/


/*void main(){

	//nothrow je izuzetak i ukoliko dodje do greske prilikom alokacije memorije da promenjliva niz dobije vrednost NULL
	//i program ce nastaviti da rad i nece baciti gresku

	int* niz = NULL;
	niz = new (nothrow) int[20];

	int mestoUNizu = 0, brojIzFajla, trazeniBroj = 3, lokacija = -1, count = 0;
	int& trazeni = lokacija;

	ifstream input;
	input.open("brojevi.txt");
	if (input.is_open()) {
		while (input >> brojIzFajla && count < 20) {
			niz[mestoUNizu] = brojIzFajla;
			mestoUNizu++;
			count++;
		}
	}
	else {
		cout << "Fajl nije moguce otvoriti" << endl;
	}

	nalazi(niz, 20, trazeniBroj, trazeni);

	cout << "Lokacija broja "<< trazeniBroj << " je :" << trazeni << endl;

	input.close();

	delete[] niz;
}*/

