#include <iostream>
#include <fstream>
#include <stdlib.h>
#include <time.h>
using namespace std;

int main()
{
    string ulaz;
    string izlaz;
    int broj;
    int i;
    
    cout << "Unesite naziv ulaznog fajla : ";
    cin >> ulaz;
    cout << "Unestie naziv izlaznog fajla :";
    cin >> izlaz;

    ofstream out( ulaz + ".dat");

    cout << "Unesite koliko brojeva ce da sadrzi ulazna datoteka : ";
    cin >> broj;

    srand(time(NULL));

    for (i = 0; i < broj; i++)
    {
        out << (rand() % 1000) << endl;
    }

    out.close();

    ifstream in( ulaz + ".dat");
    out.open( izlaz + ".dat");
    while (in >> broj) {
        if (broj > 0 && broj % 2 != 0)
        {
            out << broj << endl;
        }
    }

    in.close();
    out.close();

    return 0;
}